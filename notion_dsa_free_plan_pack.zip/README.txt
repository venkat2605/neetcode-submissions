# Quick Start

## What to import

Import these CSVs into Notion as databases:

- `01_problem_tracker.csv`
- `02_javascript_reference.csv`
- `03_pattern_recognition.csv`
- `04_current_progress.csv`
- `05_review_plan.csv`

Then import or paste these Markdown files as setup pages:

- `00_README_IMPORT_FIRST.md`
- `06_problem_page_template.md`
- `07_notion_views_buttons_setup.md`

## Best first action after import

Open `01_problem_tracker.csv` in Notion and create these views:

1. Today's Review
2. Current Problems
3. By Pattern
4. Mistakes Log
5. Solved Problems

Then create the `DSA Interview Problem` database template using `06_problem_page_template.md`.
