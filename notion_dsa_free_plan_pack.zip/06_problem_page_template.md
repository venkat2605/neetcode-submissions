# DSA Interview Problem Template

Copy this into a Notion database template inside your **Problem Tracker** database.

## Problem

## Input

## Output

## Example

## My first thought

Write what you can think of before seeing any hint.

## Brute force approach

How would I solve it in the most direct way?

## Why brute force is slow

What repeated work is happening?

## Pattern clue

What clue in the question points to the pattern?

Examples:

- Need fast lookup -> Map
- Need duplicate check -> Set
- Order does not matter but counts matter -> Frequency Map
- Need grouping -> Map with signature key
- Need top K frequent -> Frequency Map + Sort/Bucket
- Need product/sum before and after current index -> Prefix/Suffix

## My optimized idea

Do not write code yet. Explain the idea in English.

## Interview discussion

What did I miss?

## Hints received

## Final approach

## Time complexity

## Space complexity

## JavaScript concepts used

## Mistakes

## Retry notes

When should I retry this problem, and what should I focus on next time?
