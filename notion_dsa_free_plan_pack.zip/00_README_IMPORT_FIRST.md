# DSA Learning Tracker — Notion Free Plan Setup

This pack is designed for a free Notion workspace. Import the CSV files as separate databases, then use this page to set up views, templates, and buttons manually.

## Files in this pack

1. `01_problem_tracker.csv` — main database for DSA problems.
2. `02_javascript_reference.csv` — JavaScript functions and examples you learned.
3. `03_pattern_recognition.csv` — clue-to-pattern cheat sheet.
4. `04_current_progress.csv` — current phase progress.
5. `05_review_plan.csv` — spaced revision list.
6. `06_problem_page_template.md` — copy into a Notion database template.
7. `07_notion_views_buttons_setup.md` — exact free-plan setup steps.

## Import order

Import these CSVs one by one into Notion:

1. `01_problem_tracker.csv`
2. `02_javascript_reference.csv`
3. `03_pattern_recognition.csv`
4. `04_current_progress.csv`
5. `05_review_plan.csv`

After import, create one Notion page called **DSA Learning Tracker** and move/link these databases inside it.

## Recommended property types after import

For `01_problem_tracker.csv`:

| Property | Type |
|---|---|
| Problem | Title |
| Status | Select |
| Difficulty | Select |
| Phase | Select |
| Pattern | Select or Multi-select |
| Confidence | Select |
| Review count | Number |
| Retry date | Date |
| Last reviewed | Date |
| JS concepts used | Multi-select or Text |
| All long explanation fields | Text |

For `05_review_plan.csv`:

| Property | Type |
|---|---|
| Problem | Title |
| Pattern | Select |
| Attempt type | Select |
| Retry date | Date |
| Done? | Checkbox |

## Daily workflow

1. Open **Today’s Review** view.
2. Pick one problem.
3. Try for 20 minutes without looking at the final solution.
4. Write your brute force and what pattern you think applies.
5. Ask for interview-style feedback.
6. Update `Mistakes`, `Hints received`, and `Final approach`.
7. Set a new `Retry date`.

## Study rule

For every new DSA problem, use this interview flow:

1. Read the question.
2. Explain brute force.
3. Explain why brute force is slow.
4. Identify the clue in the problem.
5. Guess the pattern.
6. Discuss what you missed.
7. Learn the optimized pattern.
8. Code final solution only after the why is clear.

Generated on 2026-07-12.
