# Notion Views, Buttons, and Templates Setup

CSV import creates the rows and columns, but it cannot fully create your database views, templates, or buttons. Set these up once manually.

## 1. Create a database template

In the **Problem Tracker** database:

1. Click the arrow beside **New**.
2. Click **+ New template**.
3. Name it: `DSA Interview Problem`.
4. Paste the content from `06_problem_page_template.md`.
5. Set default properties:
   - Status = Not Started
   - Confidence = Low
   - Review count = 0

## 2. Create views in Problem Tracker

### View: Today's Review

Type: Table

Filter:

- Retry date is on or before Today
- Status is not Mastered

Sort:

- Retry date ascending

### View: Current Problems

Type: Table

Filter:

- Status is Attempting OR Status is Needs Review

### View: By Pattern

Type: Board

Group by:

- Pattern

### View: Mistakes Log

Type: Table

Filter:

- Mistakes is not empty

### View: Solved Problems

Type: Table

Filter:

- Status is Solved OR Status is Mastered

Sort:

- Last reviewed descending

## 3. Add database buttons

In **Problem Tracker**, add a new property with type **Button**.

### Button: Start

Actions:

- Edit current page
- Status -> Attempting
- Last reviewed -> Today

### Button: Solved

Actions:

- Edit current page
- Status -> Solved
- Confidence -> Medium
- Last reviewed -> Today

Then manually set Retry date:

- Solved with help -> tomorrow
- Solved mostly alone -> 3 days later
- Solved fully alone -> 7 days later

### Button: Needs Review

Actions:

- Edit current page
- Status -> Needs Review
- Confidence -> Low
- Last reviewed -> Today

Then manually set Retry date to tomorrow.

### Button: Mastered

Actions:

- Edit current page
- Status -> Mastered
- Confidence -> High
- Last reviewed -> Today

Use this only when you can explain and code the problem without help.

## 4. Recommended select values

Status:

- Not Started
- Attempting
- Solved
- Needs Review
- Revising
- Mastered

Confidence:

- Low
- Medium
- High

Difficulty:

- Easy
- Medium
- Hard

Phase:

- Arrays & Hashing
- Two Pointers
- Sliding Window
- Stack
- Binary Search
- Linked List
- Trees
- Graphs
- Dynamic Programming

Pattern:

- Hash Map Lookup
- Set / Duplicate Detection
- Frequency Map
- Map Grouping
- Frequency Map + Sort/Bucket
- Prefix/Suffix
- Two Pointers
- Sliding Window
- Stack
- Binary Search
